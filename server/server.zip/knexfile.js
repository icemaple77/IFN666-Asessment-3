module.exports = {
  client: "mysql2",
  connection: {
    host: "localhost",
    database: "ifn666",
    user: "root",
    password: "p19820301",
  },
};
